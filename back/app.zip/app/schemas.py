# app/schemas.py
from pydantic import BaseModel, EmailStr
from typing import Optional

# Схема для регистрации
class UserCreate(BaseModel):
    email: EmailStr
    password: str

# Схема для вывода (без пароля)
class UserOut(BaseModel):
    id: int
    email: EmailStr

    class Config:
        orm_mode = True

# Схема для логина
class UserLogin(BaseModel):
    email: EmailStr
    password: str

# Схема для токена
class Token(BaseModel):
    access_token: str
    token_type: str

# Дополнительная схема для payload внутри токена
class TokenData(BaseModel):
    email: Optional[str] = None